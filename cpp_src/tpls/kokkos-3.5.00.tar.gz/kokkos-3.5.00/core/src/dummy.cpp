

namespace Kokkos {
namespace AvoidCompilerWarnings {
int dontComplain() {
  // keep the compiler from complaining about emptiness
  return 0;
}
}  // namespace AvoidCompilerWarnings
}  // namespace Kokkos
