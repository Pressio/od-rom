#include <magma_v2.h>
#include <magmablas.h>
#include <magmasparse.h>
#include <magma_batched.h>

int main(void) {
	return 0;
}
