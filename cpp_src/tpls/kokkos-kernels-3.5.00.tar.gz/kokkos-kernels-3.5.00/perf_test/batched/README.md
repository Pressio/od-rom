Batched BLAS performance tests reside in `perf_test/blas/{blas,blas3}`.
