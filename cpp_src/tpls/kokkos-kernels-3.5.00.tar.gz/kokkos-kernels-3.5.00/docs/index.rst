.. Kokkos Kernels documentation master file, created by
   sphinx-quickstart on Fri Sep 24 13:19:45 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Kokkos Kernels's documentation!
==========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

Docs
====

.. doxygennamespace:: Kokkos
   :members:
.. doxygennamespace:: KokkosBlas
   :members:
.. doxygennamespace:: KokkosSparse
   :members:
.. doxygennamespace:: KokkosBatched
   :members: